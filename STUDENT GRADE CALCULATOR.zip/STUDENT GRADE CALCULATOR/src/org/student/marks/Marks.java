package org.student.marks;

import java.util.Scanner;


@SuppressWarnings("serial")
class Invaildmarks extends Exception
{
  public Invaildmarks(String str) {
	  super (str);
  }
 
}

class Takeinput
{
	

Scanner sc= new Scanner(System.in); 
  
  private final String[] sub = {"Datascience","Java","c++","Dms","Maths"};
  private double [] marks = new double[5];
  
  public void TakeMarks()  throws Exception
  {
	  
	  System.out.println("Each Subject is Outof 100 Marks");
	  
	  for(int i=0;i<5;i++)
	  {
		  System.out.println("Enter your Makrs For "+sub[i]);
		  marks[i]=sc.nextDouble();
		  if(marks[i]>100)
		  {
			  throw new Invaildmarks("You have Enter A invaild Marks");
		  }
	  }
	  
	  
  }

public double[] getMarks() {
	return marks;
}
  
  
}

class TotalMarks
{

	private double sum=0;
	
 public  void  Sum(double m[]) 
 {
	 
	 
	 for(int  i=0;i<m.length;i++)
	 {
		 sum = sum+ m[i];
	 }
	 
 }

public double getSum() {
	return sum;
}

 
}

class Average
{
	
	private double avg=0;
	public void CalAverage(double s,int num) {
		
		 avg = s/num;
		
	}
	public double getAvg() {
		return avg;
	}
	
	
}

class GradeAssign

{

	private String grade;
	
	public void AssignGrade(double avg) 
	{
		
		
		
	  if(avg<=59)
	  {
		  grade ="f";
	  }
	  else if(avg>=60&&avg<=64)
	  {
		  grade ="D";
	  }
	  else if(avg>=65&&avg<=69)
	  {
		  grade ="D+";
	  }
	  else if(avg>=70&&avg<=74)
	  {
		  grade ="C";
	  }
	  else if(avg>=75&&avg<=79)
	  {
		  grade ="C+";
	  }
	  else if(avg>=80&&avg<=84)
	  {
		  grade ="B";
	  }
	  else if(avg>=85&&avg<=89)
	  {
		  grade ="B+";
	  }
	  else if(avg>=90&&avg<=94)
	  {
		  grade ="A";
	  }
	  else if(avg>=95&&avg<=100)
	  {
		  grade= "A+";
	  }
	  
	}

	public String getGrade() {
		return grade;
	}
	
	
}

class Displayresult
{
	public void display(String grade,double m) 
	{
		System.out.println("Your Percentage is: "+m+"%"+"\nAnd Your Grade is: "+grade);
	}
}
public class Marks {

	public static void main(String[] args) throws Exception 
	{
		
		Takeinput Tk = new Takeinput();
		try 
		{
	    Tk.TakeMarks();
		}
		catch(Invaildmarks e)
		{
			System.out.println(e.getMessage());
			System.out.println("Run program again");
			System.exit(1);
		}
		TotalMarks Tm = new TotalMarks();
		Tm.Sum(Tk.getMarks());
		Average Avg = new Average();
		Avg.CalAverage(Tm.getSum(),Tk.getMarks().length );
		GradeAssign Ga = new GradeAssign();
	    Ga.AssignGrade(Avg.getAvg());
	    Displayresult Show = new Displayresult();
	    Show.display(Ga.getGrade(),Avg.getAvg());
	}

}
